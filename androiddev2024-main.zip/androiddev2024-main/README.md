USTH ICT 2024 Android Application Development
=====================================================

Students are expected to:

* Fork this repository to your github account
* Update student name and ID to this README file
* Push your commits regularly, with proper commit messages

Student Info
=======================

* Name: Nguyen Hong Minh
* ID: Bi11-183
* Group ID: 20
* Project Name: Flickr Browser

